package com.edu.stu.atten.bean.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.base.kit.MybatisMutiKit;
import com.jfinal.jui.JUIService;
import com.edu.stu.atten.bean.LeaveType;
import com.edu.stu.atten.bean.mapper.LeaveTypeMapper;
import com.edu.stu.atten.bean.service.ILeaveTypeService;

@Service("LeaveTypeService")
public class LeaveTypeService extends JUIService<LeaveType, LeaveTypeMapper> implements ILeaveTypeService {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(LeaveTypeService.class);

	public LeaveTypeService() {
		super(MybatisMutiKit.new_education_db, LeaveTypeMapper.class, LeaveType.class);
	}

	@Override
	public List<LeaveType> getLeaveTypeList() {
		Map<String, Object> example = new HashMap<String, Object>();
		example.put("interface", "getEnableList");
		logger.debug("getLeaveTypeList example = "+example);
		List<LeaveType> beanList = MybatisMutiKit.new_education_db.selectListBeanByInterface(clazzM, clazzT, example);
		return beanList;
	}

}
