package com.edu.stu.course.bean.controller;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jfinal.jui.JUIServiceController;
import com.edu.stu.course.bean.CollegeCourseNotes;
import com.edu.stu.course.bean.service.ICollegeCourseNotesService;
import com.edu.stu.course.bean.service.impl.CollegeCourseNotesService;

@Controller
@RequestMapping("/CollegeCourseNotes")
public class CollegeCourseNotesController extends JUIServiceController<CollegeCourseNotes> {
	private static Logger logger = Logger.getLogger(CollegeCourseNotesController.class);

	private static ICollegeCourseNotesService collegeCourseNotesService = new CollegeCourseNotesService();

	public CollegeCourseNotesController() {
		super(CollegeCourseNotes.class, collegeCourseNotesService);
	}

}
