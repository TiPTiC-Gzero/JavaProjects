package com.edu.stu.course.bean.mapper;

import com.edu.stu.course.bean.CollegeGradeUser2course;
import com.jfinal.db.mybatis.faces.BaseSupportMapper;

public interface CollegeGradeUser2courseMapper extends BaseSupportMapper {
	
	//根据userId，courseId更新分数 {userId,courseId,score,updateUser,updateDate}
	public int updateCourseScore(CollegeGradeUser2course bean);
}