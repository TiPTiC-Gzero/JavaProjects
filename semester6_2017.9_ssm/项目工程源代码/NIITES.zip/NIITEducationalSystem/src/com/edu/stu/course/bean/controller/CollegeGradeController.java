package com.edu.stu.course.bean.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.edu.stu.course.bean.CollegeGrade;
import com.edu.stu.course.bean.CollegeGradeUser2course;
import com.edu.stu.course.bean.service.ICollegeCourseService;
import com.edu.stu.course.bean.service.ICollegeGradeService;
import com.edu.stu.course.bean.service.impl.CollegeCourseService;
import com.edu.stu.course.bean.service.impl.CollegeGradeService;
import com.jfinal.jui.JUIServiceController;
import com.jfinal.jui.constants.SessionConstants;
import com.jfinal.kit.StrKit;

@Controller
@RequestMapping("/CollegeGrade")
public class CollegeGradeController extends JUIServiceController<CollegeGrade> {
	private static Logger logger = Logger.getLogger(CollegeGradeController.class);

	private static ICollegeGradeService collegeGradeService = new CollegeGradeService();
	private static ICollegeCourseService collegeCourseService = new CollegeCourseService();

	public CollegeGradeController() {
		super(CollegeGrade.class, collegeGradeService);
	}

	@Override
	public void add() {
		String userId = getPara("userId");//, "b5e59bd6e1da4098a28da61121e1d39b"
		logger.debug("userId = "+userId);
		if(StrKit.isBlank(userId)){
			renderJson(this.ajaxError("can not find userId !"));
			return;
		}
		
		//查询需要考核的课程列表
		//List<CollegeCourse> courceList = collegeCourseService.getCourseList(userId, true);
		
		//{userId, courseId, majorId, courseName, deleteFlag, score}
		List<Map<String, Object>> courceList = collegeCourseService.getCourseScoreListByUserId(userId);
		
		setAttr("courceList", courceList);
		setAttr("uid", userId);
		StringBuilder sb = new StringBuilder();
		if(courceList!=null && courceList.size()>0){
			for (Map<String, Object> bean : courceList) {
				sb.append(bean.get("courseId")+",");
			}
			String courceIds = sb.toString();
			courceIds = courceIds.substring(0, courceIds.length()-1);
			logger.debug("courceIds = "+courceIds);
			setAttr("courceIds", courceIds);
		}
		super.add();
	}
	
	@Override
	public void save() {
		String userId = getPara("userId");
		logger.debug("userId = "+userId);
		if(StrKit.isBlank(userId)){
			renderJson(this.ajaxError("can not find userId !"));
			return;
		}
		
		String keys = getPara("input_keys");
		if(StrKit.isBlank(keys)){
			logger.error("can not find input_keys !");
			renderJson(this.ajaxError("can not find input_keys !"));
			return;
		}
		
		List<CollegeGradeUser2course> beanList = new ArrayList<>();
		
		List<String> nameList = Arrays.asList(keys.split(","));
		if(nameList!=null && nameList.size()>0){
			for (String courseId : nameList) {
				String scoreStr = getPara(courseId);
				Float score = Float.valueOf(scoreStr);
				
				CollegeGradeUser2course bean = new CollegeGradeUser2course();
				bean.setCourseId(courseId);
				bean.setUserId(userId);
				bean.setScore(score);
				beanList.add(bean);
			}
		}
		
		int succNum = 0;
		if(beanList.size()>0){
			succNum = collegeGradeService.updateCourceScores(userId, beanList, (String) getSessionAttr(SessionConstants.USER_ID));
		}
		
		if(succNum>0){
			renderJson(this.ajaxSuccess("更新成绩成功"+succNum+"个!"));
		}else{
			renderJson(this.ajaxError("更新成绩失败!"));
		}
	}
	
}
