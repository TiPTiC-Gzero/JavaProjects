package com.edu.stu.course.bean.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jfinal.jui.JUIServiceController;
import com.edu.stu.course.bean.CollegeMajor;
import com.edu.stu.course.bean.service.ICollegeMajorService;
import com.edu.stu.course.bean.service.impl.CollegeMajorService;

@Controller
@RequestMapping("/CollegeMajor")
public class CollegeMajorController extends JUIServiceController<CollegeMajor> {
	private static Logger logger = Logger.getLogger(CollegeMajorController.class);

	private static ICollegeMajorService collegeMajorService = new CollegeMajorService();

	public CollegeMajorController() {
		super(CollegeMajor.class, collegeMajorService);
	}

	@Override
	public void add() {
		List<CollegeMajor> beanList = collegeMajorService.getCollegeMajorList();
		setAttr("beanList", beanList);
		super.add();
	}
	
	@Override
	public void edit() {
		List<CollegeMajor> beanList = collegeMajorService.getCollegeMajorList();
		setAttr("beanList", beanList);
		super.edit();
	}
}
