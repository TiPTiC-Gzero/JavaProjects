package com.edu.stu.course.bean.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.base.kit.MybatisMutiKit;
import com.jfinal.jui.JUIService;
import com.edu.stu.course.bean.CollegeMajor;
import com.edu.stu.course.bean.mapper.CollegeMajorMapper;
import com.edu.stu.course.bean.service.ICollegeMajorService;

@Service("CollegeMajorService")
public class CollegeMajorService extends JUIService<CollegeMajor, CollegeMajorMapper> implements ICollegeMajorService {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(CollegeMajorService.class);

	public CollegeMajorService() {
		super(MybatisMutiKit.new_education_db, CollegeMajorMapper.class, CollegeMajor.class);
	}

	@Override
	public List<CollegeMajor> getCollegeMajorList() {
		Map<String, Object> example = new HashMap<String, Object>();
		example.put("interface", "getEnableList");
		logger.debug(example);
		return MybatisMutiKit.new_education_db.selectListBeanByInterface(clazzM, clazzT, example);
	}

}
