package com.edu.stu.atten.bean.mapper;

import com.edu.stu.atten.bean.AttendanceRecordDetail;
import com.jfinal.db.mybatis.faces.BaseSupportMapper;

public interface AttendanceRecordDetailMapper extends BaseSupportMapper {
}