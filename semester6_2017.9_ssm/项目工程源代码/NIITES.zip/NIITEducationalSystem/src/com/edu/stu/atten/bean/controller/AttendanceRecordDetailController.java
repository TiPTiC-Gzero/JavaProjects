package com.edu.stu.atten.bean.controller;

import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.edu.stu.atten.bean.AttendanceRecordDetail;
import com.edu.stu.atten.bean.AttendanceRecordHead;
import com.edu.stu.atten.bean.service.IAttendanceRecordDetailService;
import com.edu.stu.atten.bean.service.IAttendanceRecordHeadService;
import com.edu.stu.atten.bean.service.impl.AttendanceRecordDetailService;
import com.edu.stu.atten.bean.service.impl.AttendanceRecordHeadService;
import com.jfinal.jui.JUIServiceController;
import com.jfinal.jui.constants.SessionConstants;
import com.jfinal.kit.JsonKit;
import com.jfinal.kit.StrKit;

//考勤接口类
@Controller
@RequestMapping("/AttendanceRecordDetail")
public class AttendanceRecordDetailController extends JUIServiceController<AttendanceRecordDetail> {
	private static Logger logger = Logger.getLogger(AttendanceRecordDetailController.class);

	private static IAttendanceRecordDetailService attendanceRecordDetailService = new AttendanceRecordDetailService();
	private static IAttendanceRecordHeadService attendanceRecordHeadService = new AttendanceRecordHeadService();

	public AttendanceRecordDetailController() {
		super(AttendanceRecordDetail.class, attendanceRecordDetailService);
	}

	//AttendanceRecordDetail/addRecord?type=1
	//添加一条记录到考勤明细表
	public void addRecord() {
		String userId = getSessionAttr(SessionConstants.USER_ID);
		if(StrKit.isBlank(userId)){
			renderJson(this.ajaxError("未登录！"));
			return;
		}
		//类型 － 上课1，下课2
		String type = getPara("type", "1");
		Date attDate = new Date();
		AttendanceRecordDetail bean = new AttendanceRecordDetail();
		bean.setUserId(userId);
		bean.setAttDate(attDate);
		bean.setType(Byte.valueOf(type));
		logger.debug("AttendanceRecordDetail = "+JsonKit.toJson(bean));
		int ret = attendanceRecordDetailService.save(bean, userId);
		if(ret==1){
			initAttendanceRecordHead(type, userId, attDate);
			renderJson(this.ajaxTip(200, "打卡成功！"));
		}else{
			renderJson(this.ajaxTip(300, "打卡失败！"));
		}
		return;
	}
	
	//添加或更新考勤主表信息
	private boolean initAttendanceRecordHead(String type, String userId, Date attDate) {
		AttendanceRecordHead bean = attendanceRecordHeadService.getAttendanceRecordHead(userId, attDate);
		if(bean==null){//如果bean不存在，则插入一条数据（正常为"1".equals(type)）
			AttendanceRecordHead head = new AttendanceRecordHead();
			head.setAttDate(attDate);
			head.setUserId(userId);
			if("1".equals(type)){
				head.setStartDate(attDate);
			}else if("2".equals(type)){
				head.setEndDate(attDate);
			}
			int ret = attendanceRecordHeadService.save(head, userId);
			if(ret==1){
				logger.info("success to add AttendanceRecordHead = "+JsonKit.toJson(head));
				return true;
			}else{
				logger.error("fail to add AttendanceRecordHead = "+JsonKit.toJson(head));
			}
		}else if("2".equals(type)){//如果bean存在，则更新对应的打卡时间(只会更新下课打卡时间－－取最后一次打卡时间)
			AttendanceRecordHead head = new AttendanceRecordHead();
			head.setId(bean.getId());
			head.setEndDate(attDate);
			int ret = attendanceRecordHeadService.update(head, userId);
			if(ret==1){
				logger.info("success to update AttendanceRecordHead = "+JsonKit.toJson(head));
				return true;
			}else{
				logger.error("fail to update AttendanceRecordHead = "+JsonKit.toJson(head));
			}
		}
		return false;
	}
}
