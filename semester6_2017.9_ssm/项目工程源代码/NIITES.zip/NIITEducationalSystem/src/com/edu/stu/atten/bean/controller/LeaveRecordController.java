package com.edu.stu.atten.bean.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.edu.stu.atten.bean.LeaveRecord;
import com.edu.stu.atten.bean.LeaveType;
import com.edu.stu.atten.bean.service.ILeaveRecordService;
import com.edu.stu.atten.bean.service.ILeaveTypeService;
import com.edu.stu.atten.bean.service.impl.LeaveRecordService;
import com.edu.stu.atten.bean.service.impl.LeaveTypeService;
import com.jfinal.jui.JUIServiceController;

@Controller
@RequestMapping("/LeaveRecord")
public class LeaveRecordController extends JUIServiceController<LeaveRecord> {
	private static Logger logger = Logger.getLogger(LeaveRecordController.class);

	private static ILeaveRecordService leaveRecordService = new LeaveRecordService();
	private static ILeaveTypeService leaveTypeService = new LeaveTypeService();
	
	public LeaveRecordController() {
		super(LeaveRecord.class, leaveRecordService);
	}
	
	@Override
	public void add() {
		List<LeaveType> leaveTypeList = leaveTypeService.getLeaveTypeList();
		setAttr("leaveTypeList", leaveTypeList);
		super.add();
	}

}
