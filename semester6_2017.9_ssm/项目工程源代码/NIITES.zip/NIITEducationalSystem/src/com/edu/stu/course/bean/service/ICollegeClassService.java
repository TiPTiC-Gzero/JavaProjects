package com.edu.stu.course.bean.service;

import com.jfinal.jui.IBaseService;
import com.edu.stu.course.bean.CollegeClass;

public interface ICollegeClassService extends IBaseService<CollegeClass> {

	//根据老师id－createUser获取CollegeClass
	public CollegeClass getCollegeClass(String teacherId);
}
