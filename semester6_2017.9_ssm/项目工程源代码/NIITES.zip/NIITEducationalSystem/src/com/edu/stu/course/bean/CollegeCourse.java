package com.edu.stu.course.bean;

import com.jfinal.db.bean.BaseBean;

public class CollegeCourse extends BaseBean {
    private static final long serialVersionUID = 1L;

    private String majorId;

    private String name;

    private Integer minutes;

    private String pptFileUrl;

    private Integer gradeScore;

    private Float ratio;

    private String remark;

    public String getMajorId() {
        return majorId;
    }

    public void setMajorId(String majorId) {
        this.majorId = majorId == null ? null : majorId.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public Integer getMinutes() {
        return minutes;
    }

    public void setMinutes(Integer minutes) {
        this.minutes = minutes;
    }

    public String getPptFileUrl() {
        return pptFileUrl;
    }

    public void setPptFileUrl(String pptFileUrl) {
        this.pptFileUrl = pptFileUrl == null ? null : pptFileUrl.trim();
    }

    public Integer getGradeScore() {
        return gradeScore;
    }

    public void setGradeScore(Integer gradeScore) {
        this.gradeScore = gradeScore;
    }

    public Float getRatio() {
		return ratio;
	}

	public void setRatio(Float ratio) {
		this.ratio = ratio;
	}

	public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", majorId=").append(majorId);
        sb.append(", name=").append(name);
        sb.append(", minutes=").append(minutes);
        sb.append(", pptFileUrl=").append(pptFileUrl);
        sb.append(", gradeScore=").append(gradeScore);
        sb.append(", ratio=").append(ratio);
        sb.append(", remark=").append(remark);
        sb.append(", createUser=").append(createUser);
        sb.append(", createDate=").append(createDate);
        sb.append(", updateUser=").append(updateUser);
        sb.append(", updateDate=").append(updateDate);
        sb.append(", deleteFlag=").append(deleteFlag);
        sb.append("]");
        return sb.toString();
    }
}