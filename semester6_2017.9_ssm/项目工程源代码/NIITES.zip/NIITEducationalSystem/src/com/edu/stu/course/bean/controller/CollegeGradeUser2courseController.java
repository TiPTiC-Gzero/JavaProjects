package com.edu.stu.course.bean.controller;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jfinal.jui.JUIServiceController;
import com.edu.stu.course.bean.CollegeGradeUser2course;
import com.edu.stu.course.bean.service.ICollegeGradeUser2courseService;
import com.edu.stu.course.bean.service.impl.CollegeGradeUser2courseService;

@Controller
@RequestMapping("/CollegeGradeUser2course")
public class CollegeGradeUser2courseController extends JUIServiceController<CollegeGradeUser2course> {
	private static Logger logger = Logger.getLogger(CollegeGradeUser2courseController.class);

	private static ICollegeGradeUser2courseService collegeGradeUser2courseService = new CollegeGradeUser2courseService();

	public CollegeGradeUser2courseController() {
		super(CollegeGradeUser2course.class, collegeGradeUser2courseService);
	}

}
