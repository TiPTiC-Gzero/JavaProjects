package com.edu.stu.course.bean.service;

import com.jfinal.jui.IBaseService;
import com.edu.stu.course.bean.CollegeGradeUser2course;

public interface ICollegeGradeUser2courseService extends IBaseService<CollegeGradeUser2course> {

	//根据userId，courseId更新分数 {userId,courseId,score,updateUser,updateDate}
	public int updateCourseScore(CollegeGradeUser2course bean);
}
