package com.edu.stu.atten.bean.mapper;

import com.edu.stu.atten.bean.LeaveRecord;
import com.jfinal.db.mybatis.faces.BaseSupportMapper;

public interface LeaveRecordMapper extends BaseSupportMapper {
}