package com.edu.stu.atten.bean.service;

import java.util.List;

import com.edu.stu.atten.bean.LeaveType;
import com.jfinal.jui.IBaseService;

public interface ILeaveTypeService extends IBaseService<LeaveType> {

	//查询请假类型列表
	public List<LeaveType> getLeaveTypeList();
}
