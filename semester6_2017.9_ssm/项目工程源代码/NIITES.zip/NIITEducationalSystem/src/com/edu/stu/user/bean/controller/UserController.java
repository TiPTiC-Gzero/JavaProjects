package com.edu.stu.user.bean.controller;

import java.security.GeneralSecurityException;
import java.util.HashMap;
import java.util.Map;

import javax.mail.MessagingException;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.base.kit.EmailMutiKit;
import com.edu.stu.user.bean.User;
import com.edu.stu.user.bean.service.IUserService;
import com.edu.stu.user.bean.service.impl.UserService;
import com.jfinal.aop.Before;
import com.jfinal.ext.kit.RandomCodeKit;
import com.jfinal.jui.JUIIndexInterceptor;
import com.jfinal.jui.JUIServiceController;
import com.jfinal.jui.constants.PageConstants;
import com.jfinal.jui.constants.SessionConstants;
import com.jfinal.kit.HashKit;
import com.jfinal.kit.JsonKit;
import com.jfinal.kit.StrKit;

@Controller
@RequestMapping("/User")
public class UserController extends JUIServiceController<User> {
	private static Logger logger = Logger.getLogger(UserController.class);

	private static IUserService userService = new UserService();

	public UserController() {
		super(User.class, userService);
	}
	
	@Override
	@Before(JUIIndexInterceptor.class)
	public void lookup() {
		Map<String, Object> example = JUIIndexInterceptor.getConditionMap(this);
		if(example==null){
			example = new HashMap<>();
		}
		example.put("interface", "lookup");
		this.page(example, PageConstants.jsp_lookup);
	}
	
	@Override
	public void save() {
		String userId = (String)this.getSessionAttr(SessionConstants.USER_ID);
		User bean = getBean(this.clazzT, PageConstants.ModelName);
		if(bean==null){
			renderJson(this.ajaxError("添加失败!"));
			return;
		}
		String email = bean.getEmail();
		if(StrKit.isBlank(email)){
			renderJson(this.ajaxError("邮箱信息必须输入!"));
			return;
		}
		
		//根据code的长度判断用户的类别
		String code = bean.getCode();
		if(code.length()==12){//类别=学生
			bean.setUserType(Byte.valueOf("1"));
		}else if(code.length()==4){//类别=老师
			bean.setUserType(Byte.valueOf("2"));
		}else{
			renderJson(this.ajaxError("账号格式不正确!"));
			return;
		}
		
		if(checkExistUser(code)){
			renderJson(this.ajaxError("当前账号已经注册过!"));
			return;
		}

		//生成随机6位的密码字符串
		String pwd = RandomCodeKit.toCreateNumberStr(6);
		
		//发送邮件通知用户的密码
		try {
			EmailMutiKit.sendPassword(email, pwd);
		} catch (MessagingException | GeneralSecurityException e) {
			logger.error(e);
			renderJson(this.ajaxError("发送邮件失败!"));
			return;
		}
		
		bean.setPassword(HashKit.md5(pwd));
		bean.setAutoPwdFlag(true);
		bean.setRemark("密码："+pwd);
		logger.info("bean = "+JsonKit.toJson(bean));
		int ret = this.baseService.save(bean, userId);
		if(ret==1){
			//重设置session--user
			setSessionAttr("user", bean);
			renderJson(this.ajaxSuccess("注册成功,请查看邮箱收到的登录密码，记得及时修改哦!"));
		}else{
			renderJson(this.ajaxError("注册失败!"));
		}
	}
	
	//重置密码
	public void resetPassword() {
		String uid = getSessionAttr(SessionConstants.USER_ID);
		if(StrKit.isBlank(uid)){
			renderJson(this.ajaxError("用户未登录!"));
			return;
		}
		String oldPassword = getPara("oldPassword");
		String newPassword = getPara("newPassword");
		if(StrKit.notBlank(oldPassword, newPassword)){
			//查询旧密码，比较是否正确
			User bean = userService.getById(uid);
			String dbPassword = bean.getPassword();
			
			if(!dbPassword.equals(HashKit.md5(oldPassword))){
				renderJson(this.ajaxError("旧密码不正确!"));
				return;
			}
			
			User record = new User();
			record.setId(uid);
			record.setPassword(HashKit.md5(newPassword));
			record.setAutoPwdFlag(false);
			record.setRemark("密码："+newPassword);
			logger.info("record = "+JsonKit.toJson(record));
			userService.update(record, uid);
			renderJson(this.ajaxSuccess("设置密码成功!"));
			return;
		}
		renderJson(this.ajaxError("输入信息不完整!"));
	}
	
	//检查当前账号是否已经注册
	private boolean checkExistUser(String code) {
		Map<String, Object> example = new HashMap<String, Object>();
		example.put("interface", "getMapByCode");
		example.put("code", code);
		logger.debug("checkExistUser example = "+example);
		Map<String, Object> retMap = this.baseService.getMapByInterface(example);
		logger.debug("checkExistUser retMap = "+retMap);
		return retMap!=null;
	}
}
