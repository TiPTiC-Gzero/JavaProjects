package com.edu.stu.course.bean.service.impl;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.base.kit.MybatisMutiKit;
import com.edu.stu.course.bean.CollegeCourse;
import com.edu.stu.course.bean.CollegeGrade;
import com.edu.stu.course.bean.CollegeGradeUser2course;
import com.edu.stu.course.bean.mapper.CollegeGradeMapper;
import com.edu.stu.course.bean.service.ICollegeCourseService;
import com.edu.stu.course.bean.service.ICollegeGradeService;
import com.edu.stu.course.bean.service.ICollegeGradeUser2courseService;
import com.jfinal.jui.JUIService;
import com.jfinal.kit.JsonKit;

@Service("CollegeCourseService")
public class CollegeGradeService extends JUIService<CollegeGrade, CollegeGradeMapper> implements ICollegeGradeService {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(CollegeGradeService.class);

	private ICollegeCourseService collegeCourseService = new CollegeCourseService();
	private static ICollegeGradeUser2courseService collegeGradeUser2courseService = new CollegeGradeUser2courseService();

	public CollegeGradeService() {
		super(MybatisMutiKit.new_education_db, CollegeGradeMapper.class, CollegeGrade.class);
	}

	@Override
	public int updateCourceScores(String userId, List<CollegeGradeUser2course> beanList, String operUserId) {
		CollegeGrade gollegeGrade = this.getById(userId);
		if(gollegeGrade==null){
			logger.error("can not find CollegeGrade.id = "+userId);
			return 0;
		}

		int succNum = 0;//成功个数
		
		Boolean flag = gollegeGrade.getHasCourseScoreFlag();
		if(flag!=null && flag){//更新已经有的课程成绩分数
			float allCourceScore = 0;//求课程成绩比率得分
			for (CollegeGradeUser2course g2cBean : beanList) {
				g2cBean.setId(null);
				g2cBean.setUpdateDate(new Date());
				g2cBean.setUpdateUser(operUserId);
				int ret = collegeGradeUser2courseService.updateCourseScore(g2cBean);
				if(ret==1){
					++succNum;
					allCourceScore += initCourceScore(g2cBean.getCourseId(), g2cBean.getScore());
					logger.info("success to update CollegeGradeUser2course = "+JsonKit.toJson(g2cBean));
				}else{
					logger.error("fail to update CollegeGradeUser2course = "+JsonKit.toJson(g2cBean));
				}
			}
			if(succNum>0){//设置当前用户为已经成功插入课程成绩，下次只做更新成绩操作
				gollegeGrade.setCourseScore(allCourceScore);
				this.update(gollegeGrade, operUserId);
			}
		}else{//第一次添加课程成绩
			float allCourceScore = 0;//求课程成绩比率得分
			for (CollegeGradeUser2course g2cBean : beanList) {
				int ret = collegeGradeUser2courseService.save(g2cBean, operUserId);
				if(ret==1){
					++succNum;
					allCourceScore += initCourceScore(g2cBean.getCourseId(), g2cBean.getScore());
					logger.info("success to save CollegeGradeUser2course = "+JsonKit.toJson(g2cBean));
				}else{
					logger.error("fail to save CollegeGradeUser2course = "+JsonKit.toJson(g2cBean));
				}
			}
			if(succNum>0){//设置当前用户为已经成功插入课程成绩，下次只做更新成绩操作
				gollegeGrade.setCourseScore(allCourceScore);
				gollegeGrade.setHasCourseScoreFlag(true);
				this.update(gollegeGrade, operUserId);
			}
		}
		return succNum;
	}
	
	//求当前课程分数占比得分
	private float initCourceScore(String courceId, float score) {
		CollegeCourse bean = collegeCourseService.getById(courceId);
		return score*bean.getRatio();
	}

}
