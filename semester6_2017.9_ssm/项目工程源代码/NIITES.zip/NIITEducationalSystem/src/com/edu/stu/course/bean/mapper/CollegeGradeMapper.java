package com.edu.stu.course.bean.mapper;

import com.edu.stu.course.bean.CollegeGrade;
import com.jfinal.db.mybatis.faces.BaseSupportMapper;

public interface CollegeGradeMapper extends BaseSupportMapper {
}