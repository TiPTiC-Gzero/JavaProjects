package com.edu.stu.project.bean.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jfinal.jui.JUIServiceController;
import com.jfinal.kit.StrKit;
import com.edu.stu.project.bean.Project2file;
import com.edu.stu.project.bean.service.IProject2fileService;
import com.edu.stu.project.bean.service.impl.Project2fileService;

@Controller
@RequestMapping("/Project2file")
public class Project2fileController extends JUIServiceController<Project2file> {
	private static Logger logger = Logger.getLogger(Project2fileController.class);

	private static IProject2fileService project2fileService = new Project2fileService();

	public Project2fileController() {
		super(Project2file.class, project2fileService);
	}
	
	//进入多个文件管理页面 Project2file/manageMutiFile?beanId=${id}
	public void manageMutiFile() {
		String beanId = getPara("beanId");
		if(StrKit.isBlank(beanId)){
			renderJson(this.ajaxError("can not find beanId !"));
			return;
		}
		Map<String, Object> example = new HashMap<>();
		example.put("beanId", beanId);
		logger.debug("example = "+example);
		List<Map<String, Object>> fileList = project2fileService.getListByExample(example);
		setAttr("fileList", fileList);
		render("common/manageMutiFile.jsp");
	}

}
