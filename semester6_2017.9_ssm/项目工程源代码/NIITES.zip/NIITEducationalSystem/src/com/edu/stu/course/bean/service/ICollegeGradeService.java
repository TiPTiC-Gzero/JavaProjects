package com.edu.stu.course.bean.service;

import java.util.List;

import com.edu.stu.course.bean.CollegeGrade;
import com.edu.stu.course.bean.CollegeGradeUser2course;
import com.jfinal.jui.IBaseService;

public interface ICollegeGradeService extends IBaseService<CollegeGrade> {

	//添加或更新课程成绩分数信息
	public int updateCourceScores(String userId, List<CollegeGradeUser2course> beanList, String operUserId);
}
