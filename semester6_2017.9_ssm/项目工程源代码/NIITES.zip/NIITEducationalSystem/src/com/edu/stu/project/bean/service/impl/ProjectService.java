package com.edu.stu.project.bean.service.impl;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.base.kit.MybatisMutiKit;
import com.jfinal.jui.JUIService;
import com.edu.stu.project.bean.Project;
import com.edu.stu.project.bean.mapper.ProjectMapper;
import com.edu.stu.project.bean.service.IProjectService;

@Service("ProjectService")
public class ProjectService extends JUIService<Project, ProjectMapper> implements IProjectService {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(ProjectService.class);

	public ProjectService() {
		super(MybatisMutiKit.new_education_db, ProjectMapper.class, Project.class);
	}

}
