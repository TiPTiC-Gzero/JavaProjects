package com.edu.stu.user.bean.mapper;

import com.base.kit.ConfigFileKit;
import com.base.kit.MybatisMutiKit;
import com.edu.stu.user.bean.User;
import com.jfinal.db.mybatis.kit.MybatisKit;
import com.jfinal.kit.JsonKit;

public class Test {

	public static void main(String[] arg){
		MybatisKit.start(ConfigFileKit.config_mybatis);//启动mybatis插件
		User bean = MybatisMutiKit.new_education_db.selectByPrimaryKey(UserMapper.class, User.class, "1e5cad8545c14d298843a78673e5aba4");
		System.out.print(JsonKit.toJson(bean));
	}
	
}
