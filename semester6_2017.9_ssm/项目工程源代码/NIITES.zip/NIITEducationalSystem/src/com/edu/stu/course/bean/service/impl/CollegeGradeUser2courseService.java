package com.edu.stu.course.bean.service.impl;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.base.kit.MybatisMutiKit;
import com.jfinal.jui.JUIService;
import com.edu.stu.course.bean.CollegeGradeUser2course;
import com.edu.stu.course.bean.mapper.CollegeGradeUser2courseMapper;
import com.edu.stu.course.bean.service.ICollegeGradeUser2courseService;

@Service("CollegeGradeUser2courseService")
public class CollegeGradeUser2courseService extends JUIService<CollegeGradeUser2course, CollegeGradeUser2courseMapper> implements ICollegeGradeUser2courseService {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(CollegeGradeUser2courseService.class);

	public CollegeGradeUser2courseService() {
		super(MybatisMutiKit.new_education_db, CollegeGradeUser2courseMapper.class, CollegeGradeUser2course.class);
	}

	@Override
	public int updateCourseScore(CollegeGradeUser2course bean) {
		CollegeGradeUser2courseMapper clazzMapper = MybatisMutiKit.new_education_db.createMapper(clazzM);
		return clazzMapper.updateCourseScore(bean);
	}

}
