package com.edu.stu.project.bean.controller;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.edu.stu.project.bean.Project;
import com.edu.stu.project.bean.service.IProjectService;
import com.edu.stu.project.bean.service.impl.ProjectService;
import com.jfinal.aop.Before;
import com.jfinal.jui.JUIIndexInterceptor;
import com.jfinal.jui.JUIServiceController;

@Controller
@RequestMapping("/Project")
public class ProjectController extends JUIServiceController<Project> {
	private static Logger logger = Logger.getLogger(ProjectController.class);

	private static IProjectService projectService = new ProjectService();

	public ProjectController() {
		super(Project.class, projectService);
	}
	
	//进入多个文件管理页面
	@Before(JUIIndexInterceptor.class)
	public void manageMutiFile() {
		
		render("common/manageMutiFile.jsp");
	}

}
