package com.edu.stu.user.bean.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.base.kit.MybatisMutiKit;
import com.jfinal.jui.JUIService;
import com.jfinal.kit.HashKit;
import com.jfinal.kit.JsonKit;
import com.edu.stu.user.bean.User;
import com.edu.stu.user.bean.mapper.UserMapper;
import com.edu.stu.user.bean.service.IUserService;

@Service("UserService")
public class UserService extends JUIService<User, UserMapper> implements IUserService {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(UserService.class);

	public UserService() {
		super(MybatisMutiKit.new_education_db, UserMapper.class, User.class);
	}

	@Override
	public User getUser(String userName, String passWord) throws Exception {
		User record = new User();
		record.setCode(userName);
		logger.debug(JsonKit.toJson(record));
		
		User bean = MybatisMutiKit.new_education_db.selectOne(clazzM, record);
		if(bean==null){
			throw new Exception("用户账号不存在！");
		}
		logger.debug("bean = "+JsonKit.toJson(bean));
		
		//判断账号是否被逻辑删除
		Boolean flag = bean.getDeleteFlag();
		if(flag){
			throw new Exception("用户账号被冻结，请联系管理员！");
		}
		
		String inputPwd = HashKit.md5(passWord);
		String pwd = bean.getPassword();
		logger.debug("passWord = "+passWord+", MD5 = "+inputPwd);
		logger.debug("db passWord = "+pwd);
		
		if(!inputPwd.equals(pwd)){
			throw new Exception("密码错误！");
		}
		return bean;
	}

	@Override
	public List<User> getUserList(Integer userType) {
		Map<String, Object> example = new HashMap<>();
		example.put("interface", "getUserList");
		example.put("userType", Byte.valueOf(userType.toString()));
		logger.debug("example = "+example);
		List<User> userList = MybatisMutiKit.new_education_db.selectListBeanByInterface(clazzM, clazzT, example);
		return userList;
	}

}
