package com.edu.stu.atten.bean.service;

import java.util.Date;

import com.edu.stu.atten.bean.AttendanceRecordHead;
import com.jfinal.jui.IBaseService;

public interface IAttendanceRecordHeadService extends IBaseService<AttendanceRecordHead> {

	//查询用户当天是否已经有数据了
	public AttendanceRecordHead getAttendanceRecordHead(String userId, Date attDate);
}
