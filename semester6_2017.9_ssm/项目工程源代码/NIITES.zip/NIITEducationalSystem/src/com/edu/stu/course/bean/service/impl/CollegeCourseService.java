package com.edu.stu.course.bean.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.base.kit.MybatisMutiKit;
import com.edu.stu.course.bean.CollegeCourse;
import com.edu.stu.course.bean.mapper.CollegeCourseMapper;
import com.edu.stu.course.bean.service.ICollegeCourseService;
import com.jfinal.jui.JUIService;

@Service("CollegeCourseService")
public class CollegeCourseService extends JUIService<CollegeCourse, CollegeCourseMapper> implements ICollegeCourseService {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(CollegeCourseService.class);
	
	public CollegeCourseService() {
		super(MybatisMutiKit.new_education_db, CollegeCourseMapper.class, CollegeCourse.class);
	}

	@Override
	public List<Map<String, Object>> getCourseScoreListByUserId(String userId) {
		Map<String, Object> example = new HashMap<>();
		example.put("interface", "getCourseScoreListByUserId");
		example.put("userId", userId);
		logger.debug("getCourseScoreListByUserId example = "+example);
		List<Map<String, Object>> beanList = MybatisMutiKit.new_education_db.selectListColumnsByInterface(clazzM, example);
		return beanList;
	}

	@Override
	public List<CollegeCourse> getCourseList(String userId, Boolean needExaminedFlag) {
		Map<String, Object> example = new HashMap<>();
		example.put("interface", "getCourseList");
		example.put("userId", userId);
		example.put("needExaminedFlag", needExaminedFlag);
		logger.debug("getCourseList example = "+example);
		List<CollegeCourse> beanList = MybatisMutiKit.new_education_db.selectListBeanByInterface(clazzM, clazzT, example);
		return beanList;
	}

}
