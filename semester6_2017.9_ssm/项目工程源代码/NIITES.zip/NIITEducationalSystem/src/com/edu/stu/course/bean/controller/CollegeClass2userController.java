package com.edu.stu.course.bean.controller;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jfinal.aop.Before;
import com.jfinal.jui.JUIIndexInterceptor;
import com.jfinal.jui.JUIServiceController;
import com.jfinal.kit.StrKit;
import com.edu.stu.course.bean.CollegeClass2user;
import com.edu.stu.course.bean.service.ICollegeClass2userService;
import com.edu.stu.course.bean.service.impl.CollegeClass2userService;

@Controller
@RequestMapping("/CollegeClass2user")
public class CollegeClass2userController extends JUIServiceController<CollegeClass2user> {
	private static Logger logger = Logger.getLogger(CollegeClass2userController.class);

	private static ICollegeClass2userService collegeClass2userService = new CollegeClass2userService();

	public CollegeClass2userController() {
		super(CollegeClass2user.class, collegeClass2userService);
	}

	@Override
	@Before(JUIIndexInterceptor.class)
	public void index() {
		String userId = getPara("userId");
		logger.debug("userId = "+userId);
		if(StrKit.isBlank(userId)){
			renderJson(this.ajaxError("can not find userId !"));
			return;
		}
		
		Map<String, Object> exmaple = new HashMap<>();
		exmaple.put("interface", "getClassIdByUserId");
		exmaple.put("userId", userId);

		logger.info("exmaple = "+exmaple);
		Map<String, Object> map = collegeClass2userService.getMapByInterface(exmaple);
		if(map==null){
			logger.error("can not find map -- userId = "+userId);
			//renderJson(this.ajaxError("can not find map -- userId !"));
			//return;
		}else{
			String classId = (String) map.get("classId");
			logger.info("classId = "+classId);
			setAttr("classId", classId);
		}
		super.index();
		//render("list.jsp");
	}
}
