package com.edu.stu.atten.bean.service;

import com.jfinal.jui.IBaseService;
import com.edu.stu.atten.bean.AttendanceRecordDetail;

public interface IAttendanceRecordDetailService extends IBaseService<AttendanceRecordDetail> {

}
