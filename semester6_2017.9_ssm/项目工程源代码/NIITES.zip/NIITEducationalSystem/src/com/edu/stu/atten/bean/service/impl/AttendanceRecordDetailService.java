package com.edu.stu.atten.bean.service.impl;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.base.kit.MybatisMutiKit;
import com.jfinal.jui.JUIService;
import com.edu.stu.atten.bean.AttendanceRecordDetail;
import com.edu.stu.atten.bean.mapper.AttendanceRecordDetailMapper;
import com.edu.stu.atten.bean.service.IAttendanceRecordDetailService;

@Service("AttendanceRecordDetailService")
public class AttendanceRecordDetailService extends JUIService<AttendanceRecordDetail, AttendanceRecordDetailMapper> implements IAttendanceRecordDetailService {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(AttendanceRecordDetailService.class);

	public AttendanceRecordDetailService() {
		super(MybatisMutiKit.new_education_db, AttendanceRecordDetailMapper.class, AttendanceRecordDetail.class);
	}

}
