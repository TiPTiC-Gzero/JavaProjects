package com.edu.stu.project.bean.service.impl;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.base.kit.MybatisMutiKit;
import com.jfinal.jui.JUIService;
import com.edu.stu.project.bean.Project2file;
import com.edu.stu.project.bean.mapper.Project2fileMapper;
import com.edu.stu.project.bean.service.IProject2fileService;

@Service("Project2fileService")
public class Project2fileService extends JUIService<Project2file, Project2fileMapper> implements IProject2fileService {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(Project2fileService.class);

	public Project2fileService() {
		super(MybatisMutiKit.new_education_db, Project2fileMapper.class, Project2file.class);
	}

}
