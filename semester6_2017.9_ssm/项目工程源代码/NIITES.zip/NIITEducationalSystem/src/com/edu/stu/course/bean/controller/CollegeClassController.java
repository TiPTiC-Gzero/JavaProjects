package com.edu.stu.course.bean.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jfinal.jui.JUIServiceController;
import com.edu.stu.course.bean.CollegeClass;
import com.edu.stu.course.bean.CollegeMajor;
import com.edu.stu.course.bean.service.ICollegeClassService;
import com.edu.stu.course.bean.service.ICollegeMajorService;
import com.edu.stu.course.bean.service.impl.CollegeClassService;
import com.edu.stu.course.bean.service.impl.CollegeMajorService;
import com.edu.stu.user.bean.User;
import com.edu.stu.user.bean.service.IUserService;
import com.edu.stu.user.bean.service.impl.UserService;

@Controller
@RequestMapping("/CollegeClass")
public class CollegeClassController extends JUIServiceController<CollegeClass> {
	private static Logger logger = Logger.getLogger(CollegeClassController.class);

	private static ICollegeClassService collegeClassService = new CollegeClassService();
	private static ICollegeMajorService collegeMajorService = new CollegeMajorService();
	private static IUserService userService = new UserService();

	public CollegeClassController() {
		super(CollegeClass.class, collegeClassService);
	}
	
	@Override
	public void add() {
		List<CollegeMajor> collegeMajorList = collegeMajorService.getCollegeMajorList();
		setAttr("beanList", collegeMajorList);
		
		List<User> teacherList = userService.getUserList(2);
		setAttr("teacherList", teacherList);
		super.add();
	}
	
	@Override
	public void edit() {
		List<CollegeMajor> collegeMajorList = collegeMajorService.getCollegeMajorList();
		setAttr("beanList", collegeMajorList);
		
		List<User> teacherList = userService.getUserList(2);
		setAttr("teacherList", teacherList);
		super.edit();
	}

}
