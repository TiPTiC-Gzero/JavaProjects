package com.edu.stu.course.bean.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jfinal.jui.JUIServiceController;
import com.edu.stu.course.bean.CollegeCourse;
import com.edu.stu.course.bean.CollegeMajor;
import com.edu.stu.course.bean.service.ICollegeCourseService;
import com.edu.stu.course.bean.service.ICollegeMajorService;
import com.edu.stu.course.bean.service.impl.CollegeCourseService;
import com.edu.stu.course.bean.service.impl.CollegeMajorService;

@Controller
@RequestMapping("/CollegeCourse")
public class CollegeCourseController extends JUIServiceController<CollegeCourse> {
	private static Logger logger = Logger.getLogger(CollegeCourseController.class);

	private static ICollegeCourseService collegeCourseService = new CollegeCourseService();
	private static ICollegeMajorService collegeMajorService = new CollegeMajorService();

	public CollegeCourseController() {
		super(CollegeCourse.class, collegeCourseService);
	}
	
	@Override
	public void add() {
		List<CollegeMajor> beanList = collegeMajorService.getCollegeMajorList();
		setAttr("beanList", beanList);
		super.add();
	}
	
	@Override
	public void edit() {
		List<CollegeMajor> beanList = collegeMajorService.getCollegeMajorList();
		setAttr("beanList", beanList);
		super.edit();
	}

}
