package com.edu.stu.course.bean.service;

import java.util.List;
import java.util.Map;

import com.jfinal.jui.IBaseService;
import com.edu.stu.course.bean.CollegeCourse;

public interface ICollegeCourseService extends IBaseService<CollegeCourse> {


	//查询用户所有的课程及成绩 {courseId, majorId, courseName, deleteFlag, score}
	public List<Map<String, Object>> getCourseScoreListByUserId(String userId);
	
	/**
	 * 查询课程列表
	 * @param userId 用户id
	 * @param needExaminedFlag true:需要考核，false不需要考核，null所有课程
	 * @return
	 */
	@Deprecated
	public List<CollegeCourse> getCourseList(String userId, Boolean needExaminedFlag);
	
}
