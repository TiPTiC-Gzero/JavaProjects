package com.edu.stu.course.bean.mapper;

import com.edu.stu.course.bean.CollegeCourseNotes;
import com.jfinal.db.mybatis.faces.BaseSupportMapper;

public interface CollegeCourseNotesMapper extends BaseSupportMapper {
}