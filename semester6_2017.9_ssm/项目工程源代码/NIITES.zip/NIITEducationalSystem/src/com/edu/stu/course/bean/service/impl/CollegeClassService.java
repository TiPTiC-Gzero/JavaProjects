package com.edu.stu.course.bean.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.base.kit.MybatisMutiKit;
import com.jfinal.jui.JUIService;
import com.edu.stu.course.bean.CollegeClass;
import com.edu.stu.course.bean.mapper.CollegeClassMapper;
import com.edu.stu.course.bean.service.ICollegeClassService;

@Service("CollegeClassService")
public class CollegeClassService extends JUIService<CollegeClass, CollegeClassMapper> implements ICollegeClassService {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(CollegeClassService.class);

	public CollegeClassService() {
		super(MybatisMutiKit.new_education_db, CollegeClassMapper.class, CollegeClass.class);
	}

	@Override
	public CollegeClass getCollegeClass(String teacherId) {
		Map<String, Object> example = new HashMap<>();
		example.put("interface", "getCollegeClassByTeacherId");
		example.put("teacherId", teacherId);
		logger.debug(example);
		List<CollegeClass> beanList = MybatisMutiKit.new_education_db.selectListBeanByInterface(clazzM, clazzT, example);
		if(beanList!=null && beanList.size()>0){
			return beanList.get(0);
		}
		logger.warn("can not find CollegeClass by createUser = "+teacherId);
		return null;
	}

}
