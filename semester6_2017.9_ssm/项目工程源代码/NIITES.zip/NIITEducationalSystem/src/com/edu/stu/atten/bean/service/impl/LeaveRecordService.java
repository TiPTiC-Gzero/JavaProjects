package com.edu.stu.atten.bean.service.impl;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.base.kit.MybatisMutiKit;
import com.jfinal.jui.JUIService;
import com.edu.stu.atten.bean.LeaveRecord;
import com.edu.stu.atten.bean.mapper.LeaveRecordMapper;
import com.edu.stu.atten.bean.service.ILeaveRecordService;

@Service("LeaveRecordService")
public class LeaveRecordService extends JUIService<LeaveRecord, LeaveRecordMapper> implements ILeaveRecordService {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(LeaveRecordService.class);

	public LeaveRecordService() {
		super(MybatisMutiKit.new_education_db, LeaveRecordMapper.class, LeaveRecord.class);
	}

}
