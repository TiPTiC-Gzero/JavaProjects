package com.edu.stu.project.bean.mapper;

import com.edu.stu.project.bean.ProjectFile;
import com.jfinal.db.mybatis.faces.BaseSupportMapper;

public interface ProjectFileMapper extends BaseSupportMapper {
}