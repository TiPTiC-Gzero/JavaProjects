package com.edu.stu.course.bean.service;

import java.util.List;

import com.jfinal.jui.IBaseService;
import com.edu.stu.course.bean.CollegeMajor;

public interface ICollegeMajorService extends IBaseService<CollegeMajor> {

	//查询所有专业信息列表
	public List<CollegeMajor> getCollegeMajorList();
}
