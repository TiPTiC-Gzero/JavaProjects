package com.edu.stu.project.bean.mapper;

import com.edu.stu.project.bean.Project2file;
import com.jfinal.db.mybatis.faces.BaseSupportMapper;

public interface Project2fileMapper extends BaseSupportMapper {
}