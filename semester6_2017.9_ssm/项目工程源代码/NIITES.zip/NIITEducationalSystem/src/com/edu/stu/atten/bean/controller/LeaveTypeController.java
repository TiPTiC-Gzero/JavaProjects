package com.edu.stu.atten.bean.controller;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jfinal.jui.JUIServiceController;
import com.edu.stu.atten.bean.LeaveType;
import com.edu.stu.atten.bean.service.ILeaveTypeService;
import com.edu.stu.atten.bean.service.impl.LeaveTypeService;

@Controller
@RequestMapping("/LeaveType")
public class LeaveTypeController extends JUIServiceController<LeaveType> {
	private static Logger logger = Logger.getLogger(LeaveTypeController.class);

	private static ILeaveTypeService leaveTypeService = new LeaveTypeService();

	public LeaveTypeController() {
		super(LeaveType.class, leaveTypeService);
	}

}
