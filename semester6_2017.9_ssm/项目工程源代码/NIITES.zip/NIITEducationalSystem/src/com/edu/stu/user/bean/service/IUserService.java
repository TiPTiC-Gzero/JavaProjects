package com.edu.stu.user.bean.service;

import java.util.List;

import com.edu.stu.user.bean.User;
import com.jfinal.jui.IBaseService;

public interface IUserService extends IBaseService<User> {

	//根据用户名密码获取User对象
	public User getUser(String userName, String passWord) throws Exception;
	
	public List<User> getUserList(Integer userType);
}
