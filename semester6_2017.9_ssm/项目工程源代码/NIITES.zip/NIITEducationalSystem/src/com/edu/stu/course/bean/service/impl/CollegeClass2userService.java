package com.edu.stu.course.bean.service.impl;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.base.kit.MybatisMutiKit;
import com.jfinal.jui.JUIService;
import com.edu.stu.course.bean.CollegeClass2user;
import com.edu.stu.course.bean.mapper.CollegeClass2userMapper;
import com.edu.stu.course.bean.service.ICollegeClass2userService;

@Service("CollegeClass2userService")
public class CollegeClass2userService extends JUIService<CollegeClass2user, CollegeClass2userMapper> implements ICollegeClass2userService {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(CollegeClass2userService.class);

	public CollegeClass2userService() {
		super(MybatisMutiKit.new_education_db, CollegeClass2userMapper.class, CollegeClass2user.class);
	}

}
