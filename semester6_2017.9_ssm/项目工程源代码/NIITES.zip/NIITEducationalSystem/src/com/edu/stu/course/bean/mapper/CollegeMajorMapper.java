package com.edu.stu.course.bean.mapper;

import com.edu.stu.course.bean.CollegeMajor;
import com.jfinal.db.mybatis.faces.BaseSupportMapper;

public interface CollegeMajorMapper extends BaseSupportMapper {
}