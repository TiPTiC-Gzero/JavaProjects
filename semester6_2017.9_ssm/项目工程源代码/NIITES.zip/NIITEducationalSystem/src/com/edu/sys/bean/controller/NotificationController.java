package com.edu.sys.bean.controller;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.edu.sys.bean.Notification;
import com.edu.sys.bean.service.INotificationService;
import com.edu.sys.bean.service.impl.NotificationService;
import com.jfinal.jui.JUIServiceController;
import com.jfinal.star.bean.JSONResult;

@Controller
@RequestMapping("/Notification")
public class NotificationController extends JUIServiceController<Notification> {
	private static Logger logger = Logger.getLogger(NotificationController.class);

	private static INotificationService notificationService = new NotificationService();

	public NotificationController() {
		super(Notification.class, notificationService);
	}

	/**
	 * http://localhost/NewEducationalSystem/Notification/getOneWeekNotifications
	 * 获取最近一周的公告信息
	 */
	public void getOneWeekNotifications() {
		List<Map<String, Object>> dataList = notificationService.getOneWeekContentList();
		if(dataList!=null){
			renderJson(JSONResult.success("success", dataList));
			return;
		}
		renderJson(JSONResult.error("最近一周没有公告信息！"));
	}
}
