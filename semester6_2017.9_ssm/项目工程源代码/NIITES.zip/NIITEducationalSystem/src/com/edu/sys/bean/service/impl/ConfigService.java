package com.edu.sys.bean.service.impl;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.base.kit.MybatisMutiKit;
import com.jfinal.jui.JUIService;
import com.edu.sys.bean.Config;
import com.edu.sys.bean.mapper.ConfigMapper;
import com.edu.sys.bean.service.IConfigService;

@Service("ConfigService")
public class ConfigService extends JUIService<Config, ConfigMapper> implements IConfigService {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(ConfigService.class);

	public ConfigService() {
		super(MybatisMutiKit.new_education_db, ConfigMapper.class, Config.class);
	}

}
