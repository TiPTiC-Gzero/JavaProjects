package com.edu.sys.bean.controller;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jfinal.jui.JUIServiceController;
import com.edu.sys.bean.Config;
import com.edu.sys.bean.service.IConfigService;
import com.edu.sys.bean.service.impl.ConfigService;

@Controller
@RequestMapping("/Config")
public class ConfigController extends JUIServiceController<Config> {
	private static Logger logger = Logger.getLogger(ConfigController.class);

	private static IConfigService configService = new ConfigService();

	public ConfigController() {
		super(Config.class, configService);
	}

}
