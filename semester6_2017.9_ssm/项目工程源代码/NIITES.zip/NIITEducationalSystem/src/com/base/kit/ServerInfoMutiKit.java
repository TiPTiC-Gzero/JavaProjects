package com.base.kit;

import org.apache.log4j.Logger;

import com.jfinal.plugin.IPlugin;
import com.jfinal.star.serverInfo.kit.ServerInfoKit;
import com.jfinal.star.serverInfo.plugin.ServerInfoBean;
import com.jfinal.star.serverInfo.plugin.ServerInfoPlugin;

/**
 * 获取当前环境下的文件服务器信息
 */
public class ServerInfoMutiKit {
	private static Logger logger = Logger.getLogger(ServerInfoMutiKit.class);
	
	public static ServerInfoBean main = use("main");

	private static boolean isStartFlag = false;
	
	/**
	 * 获取当前环境下的文件服务器信息
	 * @param name
	 * @return
	 */
	public static ServerInfoBean use(String name) {
		startPlugin();
		return ServerInfoKit.use(name);
	}
	
	public static void startPlugin() {
		if(!isStartFlag){
			//启动服务器信息配置插件
			IPlugin serverInfoPlugin = new ServerInfoPlugin(ConfigFileKit.config_serverInfo);
			isStartFlag = serverInfoPlugin.start();
			logger.info("start ServerInfoPlugin : "+isStartFlag);
		}
	}
}
