package com.base.kit;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.jfinal.star.file.faces.IStarFileManager;
import com.jfinal.star.file.kit.FileUploadKit;

public class FileUploadMutiKit {
	private static Logger logger = Logger.getLogger(FileUploadMutiKit.class);

	private static Map<String, IStarFileManager> starFileManagerMap = null;
	
	public static IStarFileManager getStarFileManager(String type) {
		startPlugin();
		return starFileManagerMap.get(type);
	}
	
	private static Map<String, IStarFileManager> startPlugin() {
		if(starFileManagerMap==null){
			//启动服务器信息配置插件
			ServerInfoMutiKit.startPlugin();
			
			//启动文件上传插件-----启动MybatisPlugin;ServerInfoPlugin;FileUploadPlugin
			FileUploadKit.startPlugin(ConfigFileKit.config_uploadFile);
			
			starFileManagerMap = new HashMap<>();
			starFileManagerMap.put("leaveRecord", FileUploadKit.use("leaveRecord", MybatisMutiKit.new_education_db));
			starFileManagerMap.put("studentResume", FileUploadKit.use("studentResume", MybatisMutiKit.new_education_db));
			starFileManagerMap.put("studentProject", FileUploadKit.use("studentProject", MybatisMutiKit.new_education_db));
			//starFileManagerMap.put("courcePPT", FileUploadKit.use("courcePPT", MybatisMutiKit.new_education_db));
		}
		logger.info("over init FileUploadMutiKit .......... ");
		return starFileManagerMap;
	}
	
	public static void main(String[] args) {
		File file = new File("F:/harb项目/教务管理系统软件/NEW教务管理系统软件需求.doc");
		try {
			IStarFileManager manager = FileUploadMutiKit.getStarFileManager("studentResume");
			if(manager != null){
				manager.uploadFile(file, "123", "userId321");
			}else{
				logger.warn("IStarFileManager == null");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
