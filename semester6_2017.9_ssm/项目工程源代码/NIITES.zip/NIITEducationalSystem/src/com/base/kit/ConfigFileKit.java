package com.base.kit;

import com.jfinal.kit.PropKit;

/**
 * 读取配置文件帮助类
 */
public class ConfigFileKit {
	
	public static final String CONFIG_FILE = "res/config.properties";
	
	public static String ENV = PropKit.use(ConfigFileKit.CONFIG_FILE).get("base.environment");
	
	public static String config_uploadPath = PropKit.get("uploadPath."+ENV+".config");
	
	public static String config_mybatis = PropKit.get("mybatis."+ENV+".config");

	public static String config_serverInfo = PropKit.get("serverInfo."+ENV+".config");
	
	public static String config_uploadFile = PropKit.get("uploadFile."+ENV+".config");

}
