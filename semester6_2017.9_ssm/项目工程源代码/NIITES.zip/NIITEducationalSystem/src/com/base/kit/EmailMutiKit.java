package com.base.kit;

import java.security.GeneralSecurityException;

import javax.mail.MessagingException;

import com.jfinal.star.email.kit.EmailKit;
import com.jfinal.star.email.plugin.ITitleFace;

public class EmailMutiKit {

	//启动发送邮件插件
	public static EmailKit kit = EmailKit.use("res/email/email-sender.properties", "res/email/email-receiver.properties");
	
	public static void sendPassword(String email, final String password) throws MessagingException, GeneralSecurityException {
		//初始化邮件标题
		ITitleFace titleFace = new ITitleFace() {
			@Override
			public String initTitle(String title) {
				return title;
			}
		};
		EmailMutiKit.kit.sendTemplateByToEmails(email, "sendPassword", titleFace, password);
	}
}
