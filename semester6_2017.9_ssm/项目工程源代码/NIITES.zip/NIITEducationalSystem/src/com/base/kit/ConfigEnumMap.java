package com.base.kit;

import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.jfinal.kit.PropKit;

public class ConfigEnumMap extends ConfigFileKit {

	@SuppressWarnings("unchecked")
	public static Map<Integer, String> statusEnumMap = JSON.parseObject(PropKit.get("statusEnumMap"), Map.class);
	
	public static void main(String[] args) {
		System.out.println(statusEnumMap);
	}
}
