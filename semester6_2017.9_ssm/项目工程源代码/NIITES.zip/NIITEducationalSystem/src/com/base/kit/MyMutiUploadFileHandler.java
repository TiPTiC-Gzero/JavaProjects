package com.base.kit;

import java.io.File;
import java.text.MessageFormat;

import org.apache.log4j.Logger;

import com.jfinal.star.file.faces.impl.AbstractUploadFileHandler;

public class MyMutiUploadFileHandler extends AbstractUploadFileHandler {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(MyMutiUploadFileHandler.class);

	@Override
	public String initNewFilePath(File file, String filePathFormat, String saveRootPath, String userId, String beanId) {
		String fileName = initFileName_UUID(file);
		//{0}/xxx/{1}/xxx/{2} ---> {saveRootPath}/xxx/{userId}/xxx/{fileName}
		String newFilePath = MessageFormat.format(filePathFormat, saveRootPath, userId, fileName);
		logger.debug(">>>>>>>newPath = "+newFilePath);
		return newFilePath;
	}

}
