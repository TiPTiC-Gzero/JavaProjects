package com.base.interceptor;

import org.apache.log4j.Logger;

import com.base.controller.IndexController;
import com.edu.stu.user.bean.User;
import com.jfinal.aop.Interceptor;
import com.jfinal.aop.Invocation;
import com.jfinal.core.Controller;

/**
 * 用户访问拦截器
 */
public class ManagerInterceptor implements Interceptor {
	private static Logger logger = Logger.getLogger(ManagerInterceptor.class);

	@Override
	public void intercept(Invocation inv) {
		Controller controller = inv.getController();
		User userBean = controller.getSessionAttr("user");
		if(userBean==null){
			controller.redirect(IndexController.Page_login);
			return;
		}
		
		Byte type = userBean.getUserType();
		if(type==null){
			logger.warn("不是用户，无权访问！");
			controller.setAttr("page_error", "不是用户，无权访问！");
			controller.redirect(IndexController.Page_login);
			return;
		}
		
		inv.invoke();
	}

}
