package com.base.config;
/**
 * author:JFinal开源中国社区
 */
import com.edu.sys.bean.controller.ConfigController;
import com.edu.sys.bean.controller.NotificationController;
import com.jfinal.config.Routes;

public class SystemRoutes extends Routes {

	@Override
	public void config() {
		
		//系统参数管理
		this.add("/Config", ConfigController.class, "/new_education_db/page/Config");
		//系统公告管理
		this.add("/Notification", NotificationController.class, "/new_education_db/page/Notification");
	}

}
