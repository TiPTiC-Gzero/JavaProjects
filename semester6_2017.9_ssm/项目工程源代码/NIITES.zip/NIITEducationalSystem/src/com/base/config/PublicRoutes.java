package com.base.config;
/**
 * author:JFinal开源中国社区
 */
import com.base.file.controller.jfinal.BaseFileCommonController;
import com.base.file.controller.jfinal.BaseFilePageController;
import com.base.file.controller.jfinal.BaseFileUploaderController;
import com.jfinal.config.Routes;

public class PublicRoutes extends Routes {

	@Override
	public void config() {
		//进入上传页面
		this.add("/baseFilePage", BaseFilePageController.class, "/");
		//文件信息查询；文件下载；文件删除接口
		this.add("/baseFileCommon", BaseFileCommonController.class);
		//上传文件
		this.add("/baseStarFile", BaseFileUploaderController.class);
	}

}
