package com.base.config;
/**
 * author:JFinal开源中国社区
 */
import com.edu.stu.atten.bean.controller.AttendanceRecordDetailController;
import com.edu.stu.atten.bean.controller.AttendanceRecordHeadController;
import com.edu.stu.atten.bean.controller.LeaveRecordController;
import com.edu.stu.atten.bean.controller.LeaveTypeController;
import com.edu.stu.course.bean.controller.CollegeClass2userController;
import com.edu.stu.course.bean.controller.CollegeClassController;
import com.edu.stu.course.bean.controller.CollegeCourseController;
import com.edu.stu.course.bean.controller.CollegeCourseNotesController;
import com.edu.stu.course.bean.controller.CollegeGradeController;
import com.edu.stu.course.bean.controller.CollegeMajorController;
import com.edu.stu.project.bean.controller.Project2fileController;
import com.edu.stu.project.bean.controller.ProjectController;
import com.edu.stu.user.bean.controller.ResumeController;
import com.edu.stu.user.bean.controller.UserController;
import com.jfinal.config.Routes;

/**
 * 版位相关的路由配置
 */
public class StudentRoutes extends Routes {

	@Override
	public void config() {
		//用户管理
		this.add("/User", UserController.class, "/new_education_db/page/User");
		//简历管理
		this.add("/Resume", ResumeController.class, "/new_education_db/page/Resume");
		
		//考勤管理
		this.add("/AttendanceRecordHead", AttendanceRecordHeadController.class, "/new_education_db/page/AttendanceRecordHead");
		this.add("/AttendanceRecordDetail", AttendanceRecordDetailController.class, "/new_education_db/page/AttendanceRecordDetail");
		//请假管理
		this.add("/LeaveType", LeaveTypeController.class, "/new_education_db/page/LeaveType");
		this.add("/LeaveRecord", LeaveRecordController.class, "/new_education_db/page/LeaveRecord");
		
		//专业管理
		this.add("/CollegeMajor", CollegeMajorController.class, "/new_education_db/page/CollegeMajor");
		//班级管理
		this.add("/CollegeClass", CollegeClassController.class, "/new_education_db/page/CollegeClass");
		//学生分班管理
		this.add("/CollegeClass2user", CollegeClass2userController.class, "/new_education_db/page/CollegeClass2user");
		//课程管理
		this.add("/CollegeCourse", CollegeCourseController.class, "/new_education_db/page/CollegeCourse");
		//学生课程笔记管理
		this.add("/CollegeCourseNotes", CollegeCourseNotesController.class, "/new_education_db/page/CollegeCourseNotes");
		//学生成绩管理
		this.add("/CollegeGrade", CollegeGradeController.class, "/new_education_db/page/CollegeGrade");
		
		//学生上传项目文件管理
		this.add("/Project", ProjectController.class, "/new_education_db/page/Project");
		this.add("/Project2file", Project2fileController.class, "/new_education_db/page/Project2file");
	}

}
