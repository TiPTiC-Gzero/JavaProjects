package com.base.config;
/**
 * author:JFinal开源中国社区
 */
import java.io.File;

import org.apache.log4j.Logger;

import com.base.controller.IndexController;
import com.base.interceptor.LoginActionInterceptor;
import com.base.interceptor.PermissionHandler;
import com.base.kit.ConfigFileKit;
import com.jfinal.config.Constants;
import com.jfinal.config.Handlers;
import com.jfinal.config.Interceptors;
import com.jfinal.config.JFinalConfig;
import com.jfinal.config.Plugins;
import com.jfinal.config.Routes;
import com.jfinal.core.JFinal;
import com.jfinal.db.mybatis.kit.MybatisKit;
import com.jfinal.kit.PropKit;
import com.jfinal.render.ViewType;
import com.jfinal.template.Engine;



/**
 * API引导式配置
 */
public class JFinalConfigSys extends JFinalConfig {
	private static Logger logger = Logger.getLogger(JFinalConfigSys.class);
	
	/**
	 * 配置常量
	 */
	@Override
	public void configConstant(Constants me) {
		// 加载少量必要配置，随后可用PropKit.get(...)获取值
		PropKit.use(ConfigFileKit.CONFIG_FILE);
		me.setDevMode(PropKit.getBoolean("devMode", true));
		
		//不进行配置时的缺省配置为 FreeMarker。
		me.setViewType(ViewType.JSP);
		
		//设置上传文件的接收目录
		String uploadPath = initBaseUploadPath();
		me.setBaseUploadPath(uploadPath);
	}
	
	//初始化上传文件默认保存位置 
	private static String initBaseUploadPath() {
		String uploadPath = ConfigFileKit.config_uploadPath;
		logger.info("uploadPath = "+uploadPath);
		File uploadFileDir = new File(uploadPath);
		if(!uploadFileDir.exists()){
			boolean b = uploadFileDir.mkdirs();
			if(!b){
				logger.error("当前上传文件目录（"+uploadPath+"）不存在，创建失败，请检查是否有权限！");
			}else{
				logger.info("success to create file dir = "+uploadPath);
			}
		}
		return uploadPath;
	}
	
	/**
	 * 配置路由
	 */
	@Override
	public void configRoute(Routes me) {
		me.add("/", IndexController.class, "/");	// 第三个参数为该Controller的视图存放路径
		me.add("/NewEducationalSystem", IndexController.class, "/");

		me.add(new PublicRoutes());
		me.add(new SystemRoutes());
		me.add(new StudentRoutes());
	}

	@Override
	public void configEngine(Engine me) {
	}
	
	/**
	 * 配置插件
	 */
	@Override
	public void configPlugin(Plugins me) {
		MybatisKit.start(ConfigFileKit.config_mybatis);//启动mybatis插件
	}
	
	/**
	 * 配置全局拦截器
	 */
	@Override
	public void configInterceptor(Interceptors me) {
		me.add(new LoginActionInterceptor());//拦截请求，未跳转到登录页面
	}
	
	/**
	 * 配置处理器
	 */
	@Override
	public void configHandler(Handlers me) {
		me.add(new PermissionHandler());//权限拦截（只有管理员能访问管理界面）
	}
	
	/**
	 * 建议使用 JFinal 手册推荐的方式启动项目
	 * 运行此 main 方法可以启动项目，此main方法可以放置在任意的Class类定义中，不一定要放于此
	 */
	public static void main(String[] args) {
		JFinal.start("WebRoot", 1521, "/", 5);
	}
}
