package com.base.file.controller.jfinal;

import java.io.File;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.base.file.service.impl.MyStarFileManagerService;
import com.jfinal.db.bean.file.BaseFileBean;
import com.jfinal.jui.constants.SessionConstants;
import com.jfinal.kit.JsonKit;
import com.jfinal.kit.PathKit;
import com.jfinal.kit.StrKit;
import com.jfinal.star.bean.JSONResult;
import com.jfinal.star.file.controller.AbstractJFinalStarFileController;
import com.jfinal.star.file.service.IStarFileManagerService;

/**
 * 文件信息查询；文件下载；文件删除接口
 */
public class BaseFileCommonController extends AbstractJFinalStarFileController {
	private static Logger logger = Logger.getLogger(BaseFileCommonController.class);

	private static IStarFileManagerService starFileManagerService = null;

	@Override
	protected IStarFileManagerService initStarFileManager() {
		if(starFileManagerService==null){
			starFileManagerService = new MyStarFileManagerService();
		}
		return starFileManagerService;
	}

	@Override
	protected String getSessionValue_UserId(HttpServletRequest request, HttpServletResponse response) {
		String userId = (String) request.getSession(true).getAttribute(SessionConstants.USER_ID);
		return userId;
	}

	/**
	 * localhost/baseFileCommon/getFileInfo?type=H5ActivityUser&id=2ff6e46c705942c592175e6801f19f36
	 * 返回：
	 * {
		message: "success!",
		statusCode: 200,
		data: {
				id: "2ff6e46c705942c592175e6801f19f36",
				createUser: "anonymousId",
				filePath: "H5ActivityUser/094a912cf4ee49c2a71f8af275c94faf.jpg",
				fileServerId: "ixt.server.local",
				tableName: "ixt_edge_db.ixt_h5_activity_file",
				name: "ER图任务　.jpg",
				urlFilePath: "http://127.0.0.1:1521/H5ActivityUser/094a912cf4ee49c2a71f8af275c94faf.jpg",
				absFilePath: "d:/test/ixt_res/H5ActivityUser/094a912cf4ee49c2a71f8af275c94faf.jpg",
				deleteFlag: false,
				createDate: "2017-06-29",
				updateDate: "2017-06-29",
				updateUser: "anonymousId",
				size: 123233
			}
		}
	 */
	public void getFileInfo() {
		String type = getPara("type");
		String id = getPara("id");
		
		String retStr = getFileInfo(type, id);
		renderJson(retStr);
	}

	/**
	 * 根据文件表id下载文件

	 */
	public void downFile() {
		String type = getPara("type");
		String id = getPara("id");//fileId
		
		try {
			BaseFileBean bean = super.downFile(true, type, id);
			String absFilePath = bean.getAbsFilePath();
			File file = new File(absFilePath);
			if(StrKit.isBlank(absFilePath) || !file.isFile()){
				String webRootPath = PathKit.getWebRootPath();
				String filePath = bean.getFilePath();
				String newFilePath = null;
				if(filePath.startsWith("/") || filePath.startsWith("\\")){
					newFilePath = webRootPath+filePath;
				}else{
					newFilePath = webRootPath+"/"+filePath;
				}
				file = new File(newFilePath);
				if(file.isFile()){
					logger.debug("newFilePath = "+newFilePath);
					renderFile(file);
					return;
				}else{
					renderJson(JSONResult.error("下载文件失败!"));
					return;
				}
			}
			String fileName = bean.getName();
			logger.info("down file name = "+fileName);
			logger.info("BaseFileBean = "+JsonKit.toJson(bean));
			
			renderFile(file, fileName);
		} catch (Exception e) {
			renderJson(JSONResult.error(e.getMessage()));
		}
	}
	
	/**
	 * 删除文件
	 * localhost/baseFileCommon/deleteFile?type=xxx&beanId=xxx
	 */
	public void deleteFile(){
		String type = getPara("type");
		String beanId = getPara("beanId");
		
		String retStr = super.deleteFile(true, type, beanId);
		renderJson(retStr);
	}
}
