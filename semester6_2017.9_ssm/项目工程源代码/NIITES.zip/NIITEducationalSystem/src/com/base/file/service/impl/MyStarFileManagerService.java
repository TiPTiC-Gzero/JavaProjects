package com.base.file.service.impl;
/**
 * author:JFinal开源中国社区
 */
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.base.kit.FileUploadMutiKit;
import com.jfinal.star.file.faces.IStarFileManager;
import com.jfinal.star.file.service.impl.AbstractStarFileManagerService;

/**
 * com.jfinal.star.file.service.IStarFileManagerService
 */
@Service("starFileManagerService")
public class MyStarFileManagerService extends AbstractStarFileManagerService {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(MyStarFileManagerService.class);

	@Override
	public IStarFileManager initStarFileManager(String type) {
		IStarFileManager starFileManager = FileUploadMutiKit.getStarFileManager(type);
		if(starFileManager==null){
			logger.error("can not find type ========= "+type);
		}else{
			logger.info("success get IStarFileManager by type == "+type);
		}
		return starFileManager;
	}

}
