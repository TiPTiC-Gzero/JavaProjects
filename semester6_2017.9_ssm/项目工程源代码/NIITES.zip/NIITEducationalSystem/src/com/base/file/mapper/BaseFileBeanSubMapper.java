package com.base.file.mapper;

import com.jfinal.star.file.mapper.BaseFileBeanMapper;

public interface BaseFileBeanSubMapper extends BaseFileBeanMapper {

	//public BaseFileBean selectByCode();
}
