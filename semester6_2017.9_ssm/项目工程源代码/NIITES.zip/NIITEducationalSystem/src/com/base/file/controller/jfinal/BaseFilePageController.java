package com.base.file.controller.jfinal;

import com.jfinal.aop.Before;
import com.jfinal.core.Controller;
import com.jfinal.jui.JUIIndexInterceptor;

public class BaseFilePageController extends Controller {

	//上传单个文件页面 baseFilePage/toFilePage
	@Before(JUIIndexInterceptor.class)
	public void toFilePage() {
		render("common/file.jsp");
	}
	
	//进入批量上传文件页面  baseFilePage/addMutiFile
	@Before(JUIIndexInterceptor.class)
	public void addMutiFile() {
		render("common/addMutiFile.jsp");
	}
	
	//进入多个文件管理页面
	public void manageMutiFile() {
		render("common/manageMutiFile.jsp");
	}
}
