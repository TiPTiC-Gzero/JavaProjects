package com.base.file.controller.jfinal;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.base.file.service.impl.MyStarFileManagerService;
import com.jfinal.jui.constants.SessionConstants;
import com.jfinal.star.file.controller.AbstractJFinalStarFileController;
import com.jfinal.star.file.service.IStarFileManagerService;

/**
 * 上传文件
 */
public class BaseFileUploaderController extends AbstractJFinalStarFileController {

	private static IStarFileManagerService starFileManagerService = null;
	
	@Override
	protected IStarFileManagerService initStarFileManager() {
		if(starFileManagerService==null){
			starFileManagerService = new MyStarFileManagerService();
		}
		return starFileManagerService;
	}
	
	@Override
	protected String getSessionValue_UserId(HttpServletRequest request, HttpServletResponse response) {
		String userId = (String) request.getSession(true).getAttribute(SessionConstants.USER_ID);
		return userId;
	}

	//上传学生请假图片文件 localhost/baseStarFile/uploadFile_leaveRecord?id=xxx&file=xxxx
	public void uploadFile_leaveRecord() {
		uploadFile(false, "leaveRecord", "inputFile");
	}
	
	//上传学生简历文件 localhost/baseStarFile/uploadFile_studentResume?id=xxx&file=xxxx
	public void uploadFile_studentResume() {
		uploadFile(false, "studentResume", "inputFile");
	}

	//上传项目文件 localhost/baseStarFile/uploadFile_studentProject?id=xxx&file=xxxx
	public void uploadFile_studentProject() {
		uploadFile(false, "studentProject", "inputFile");
	}

	//上传课程附件 localhost/baseStarFile/uploadFile_courcePPT?id=xxx&file=xxxx
	public void uploadFile_courcePPT() {
		uploadFile(false, "courcePPT", "inputFile");
	}
}
