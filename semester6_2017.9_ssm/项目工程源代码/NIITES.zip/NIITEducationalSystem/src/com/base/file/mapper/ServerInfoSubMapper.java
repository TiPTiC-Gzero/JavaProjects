package com.base.file.mapper;

import com.jfinal.star.file.mapper.ServerInfoMapper;

public interface ServerInfoSubMapper extends ServerInfoMapper {
}