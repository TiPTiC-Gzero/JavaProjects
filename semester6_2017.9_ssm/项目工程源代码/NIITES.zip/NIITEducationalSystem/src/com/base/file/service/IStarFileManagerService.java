package com.base.file.service;

import com.jfinal.star.file.faces.IStarFileManager;

public interface IStarFileManagerService  {

	public IStarFileManager init(String fileType);
}
