package com.ssm.pojo;

import java.util.List;

//用户包装类型pojo 
//包装所需要的查询条件
//为了系统良好的扩展性，对原始生成的po进行扩展
public class UserQueryVo {

	private User user;
	//传入多个id
	private List<Integer> ids;	
	//包装所需要的查询条件
	
	//用户查询条件
	private UserCustom userCustom;//用户信息传入存储
	//查询条件等

	public UserCustom getUserCustom() {
		return userCustom;
	}

	public void setUserCustom(UserCustom userCustom) {
		this.userCustom = userCustom;
	}

	public List<Integer> getIds() {
		return ids;
	}

	public void setIds(List<Integer> ids) {
		this.ids = ids;
	}
}
	