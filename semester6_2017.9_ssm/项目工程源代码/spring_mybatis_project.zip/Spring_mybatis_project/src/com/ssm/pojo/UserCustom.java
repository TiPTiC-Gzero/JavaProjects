package com.ssm.pojo;

import com.ssm.pojo.User;

//用户扩展类
public class UserCustom extends User{//将次作为mapper查询结果返回结果集
	//可以扩展用户信息
}
