package com.ssm.controller.converter;

//自定义的参数绑定类型
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.core.convert.converter.Converter;

public class CustomDateConverter implements Converter<String, Date>{

	@Override
	public Date convert(String time) {
		
		//将日期串转成日期类型
		SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try{
			//直接转回
			return simpleDateFormat.parse(time);
		}
		catch(ParseException e){
			e.printStackTrace();
		}
		
		return null;
	}
	
}
