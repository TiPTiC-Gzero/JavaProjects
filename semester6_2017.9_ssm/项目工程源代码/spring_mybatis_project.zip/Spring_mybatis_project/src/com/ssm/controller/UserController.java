package com.ssm.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ssm.pojo.User;
import com.ssm.pojo.UserCustom;
import com.ssm.service.UserService;

//用户的controller
//requestMapping 是定义controller方法对应的url  从而进行 处理器的映射

//为了对url进行管理  定义根路径 最终对url的访问时根路径+子路径 /user/querUser.action
@Controller
@RequestMapping("/user")
public class UserController {// 没有借口 可以定义其他方法

	//注入service 更换到动态数据查询
	@Autowired
	private UserService userService;
	
	// 将mapping url和方法名相同 方便维护
	// @requestMapping 实现对queryUser方法和url进行映射 一个方法对应一个url
	
	@RequestMapping("/queryUser")
	public ModelAndView queryUser() throws Exception {
		// 调用service查找数据库 查询列表  动态数据 不再静态 
		//此处没有查询条件
		List<UserCustom> userList = userService.findUserList(null);
//		// 向list中填充静态数据
//		User user1 = new User();
//		user1.setUsername("阿里巴巴");
//		user1.setSex("1");
//		user1.setAddress("香港");
//
//		User user2 = new User();
//		user2.setUsername("网易");
//		user2.setSex("1");
//		user2.setAddress("北京");
//
//		userList.add(user1);
//		userList.add(user2);

		// 创建modelAndView 准备填充数据 设置视图
		ModelAndView modelAndView = new ModelAndView();
		// 填充数据 相当于request的setAttribute 在jsp页面中通过userList取得数据
		modelAndView.addObject("userList", userList);
		// 视图
		// modelAndView.setViewName("/WEB-INF/jsp/user/userList.jsp");
		modelAndView.setViewName("user/userList");
		// 最后返回modelAndView
		return modelAndView;
	}
	
	//用户信息修改网页面显示 
	//限制http请求方法
	@RequestMapping(value="/editUser",method={RequestMethod.GET,RequestMethod.POST})
	public String editUser(Model model,@RequestParam(value="id",required=true) Integer userid)throws Exception{//string 类型返回视图 拼接
		//调用service 根据用户id查询用户信息
		UserCustom userCustom=userService.findUserById(userid);
		
//		//创建m&v
//		ModelAndView modelAndView = new ModelAndView();
//		
//		//将用户信息放入到model中
//		modelAndView.addObject("userCustom",userCustom);
//		//用户修改页面
//		modelAndView.setViewName("user/editUser");
		
		//使用形参中的model将model数据传到页面
		//相当于modelAndView.addObject方法
		model.addAttribute("userCustom",userCustom);
		
		return "user/editUser";
	}
	//用户信息修改提交
		@RequestMapping("/editUserSubmit")
		public String editUserSubmit(HttpServletRequest request,Integer id,UserCustom userCustom)throws Exception{
			
			userService.updateUser(id, userCustom);
			
			//重定向 此时由于在同一个controller内 不加入限制根路径
//			return "redirect:queryUser.action";
//			return "forward:queryUser.action";
			return "success";
		}
	
	
}
