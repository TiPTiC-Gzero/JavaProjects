package com.ssm.service;

import java.util.List;

import com.ssm.pojo.UserCustom;
import com.ssm.pojo.UserQueryVo;
//定义service
//用户管理service 
public interface UserService {
	//用户查询列表
	public List<UserCustom> findUserList(UserQueryVo userQueryVo)throws Exception;
	
	//id查询用户数据
	public UserCustom findUserById(int id) throws Exception;
	
	//更新用户信息 传入id 进行用户信息维护
	public void updateUser(int id,UserCustom userCustom) throws Exception;
	
	
}
