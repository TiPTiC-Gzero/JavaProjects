package com.ssm.service.impl;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.ssm.mapper.UserMapper;
import com.ssm.mapper.UserMapper2;
import com.ssm.pojo.User;
import com.ssm.pojo.UserCustom;
import com.ssm.pojo.UserQueryVo;
import com.ssm.service.UserService;

//用户管理
//service的实现类
public class UserServiceImpl implements UserService{

	//进行注入操作
	@Autowired
	private UserMapper userMapper;
	
	@Autowired
	private UserMapper2 userMapper2;
	
	@Override
	public List<UserCustom> findUserList(UserQueryVo userQueryVo) throws Exception {
		//上面的userQueryVo 通过下面return直接从service 传到dao
		
		//通过userMapper.xml查询数据库
		return  userMapper.findUserList(userQueryVo);
	}

	@Override
	public UserCustom findUserById(int id) throws Exception {
		User user=userMapper2.selectByPrimaryKey(id);
		//中间业务处理
		//返回userCustom
		UserCustom userCustom=new UserCustom();
		
		//将user的内容拷贝到userCustom
		BeanUtils.copyProperties(user, userCustom);
		
		return userCustom;
	
	}

	@Override
	public void updateUser(int id, UserCustom userCustom) throws Exception {
		// 通常在service接口有对关键参数进行校验
		//检验id是否为空 如果为空跑出异常
		//更新用户信息
		//需要传入id
		userCustom.setId(id);
		userMapper2.updateByPrimaryKey(userCustom);
	}

}
