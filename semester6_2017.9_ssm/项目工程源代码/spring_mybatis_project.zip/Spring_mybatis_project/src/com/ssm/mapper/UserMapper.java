package com.ssm.mapper;

import java.util.List;

import com.ssm.pojo.User;
import com.ssm.pojo.UserCustom;
import com.ssm.pojo.UserQueryVo;
//Mapper接口 ----mybatis的mapper代理开发
//用户信息管理
public interface UserMapper {
	//借口
	//用户信息综合查询
	public List<UserCustom> findUserList(UserQueryVo userQueryVo) throws Exception;
	//用户信息综合查询总数--简单类型
	public int findUserCount(UserQueryVo userQueryVo) throws Exception;
	//根据id查询接口使用resultMap输出
	public User findUserById(int id) throws Exception;
	//查找用户
	public User findUserByIdResultMap(int id) throws Exception;
	//更新用户
	public void updateUser(User user)throws Exception;
	//插入用户
	public void insertUser(User user)throws Exception;
	//删除用户
	public void deleteUser(int id)throws Exception;
	//根据用户名查找
	public List<User> findUserByName(String name)throws Exception;
	
	
}
