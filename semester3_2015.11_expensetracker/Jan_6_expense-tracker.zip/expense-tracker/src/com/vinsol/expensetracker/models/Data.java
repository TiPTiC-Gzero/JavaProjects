package com.vinsol.expensetracker.models;

import java.util.List;

public class Data {
	
	public List<Entry> expenses;
	public List<Favorite> favorites;

}
