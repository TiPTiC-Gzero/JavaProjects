/**
 * Copyright (c) 2012 Vinayak Solutions Private Limited 
 * See the file license.txt for copying permission.
*/     


package com.vinsol.expensetracker.models;

public class GraphDataList extends ListDatetimeAmount {
	
	public String idList;
	
}
