package com.vinsol.expensetracker.models;

public class Sync {
	
	public Data add;
	public Data update;
	public Data delete;
	public String timestamp;
	
}
