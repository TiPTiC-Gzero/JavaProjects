/**
 * Copyright (c) 2012 Vinayak Solutions Private Limited 
 * See the file license.txt for copying permission.
*/     


package com.vinsol.expensetracker.models;

public class ListDatetimeAmount {
	
	public String dateTime;
	public String amount;
	
}
